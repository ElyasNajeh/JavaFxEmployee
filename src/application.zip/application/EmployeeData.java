package application;

import java.util.ArrayList;

public class EmployeeData {
	public static ArrayList<Employee> employeeList = new ArrayList<>();
}
